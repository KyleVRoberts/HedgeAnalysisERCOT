
require('readr');require('tidyverse');require('tidyquant');require('tinytex')




#Creates xtsobject of combined revenues from both HC & EL real or simulated data
RevsT<-function(Gen1,Gen2,Hp1=22.55,Hp2=24.5,Hv1,Hv2,Node1,Node2,Mp,hOp=0,hOv=0){
  revT<-as.numeric(0)  
  for(i in 1:length(Mp)){
    revT[i]<- Hp1*Hv1[[i]]+Hp2*Hv2[[i]]+Mp[[i]]*(Gen1[[i]]-Hv1[[i]]+Gen2[[i]]-Hv2[[i]])+Gen1[[i]]*(Node1[[i]]-Mp[[i]])+Gen2[[i]]*(Node2[[i]]-Mp[[i]])+.25*hOv*(Mp[[i]]-hOp)
  }
  revT<-xts(revT,order.by=index(Mp))
}
#removes Infinite NA & NaN values from data
Inf.rm<-function(x){x<-x[is.finite(rowSums(x))]}
#Creates a kernel Probability Density Function, populates the curve with n points & then samples from curve
rDens <- function(n, z, dat, kernel="gaussian") {
  
  z<-density(z)
  width <- z$bw                              
  as.numeric(sample(dat, n, replace=TRUE) + rnorm(n,sd=width))    
}
#Takes a vector of Revenues (from RevsT) and creates an xts object of periodic P/L as a running account balance with N=# of periods to return if full sequence is not desired
runAcct<-function(y,N=NULL){
  x<-as.numeric(0)
  y<-apply.daily(y,sum)
  for(i in 2:(length(y))){
    x[i]<-x[i-1]+y[i]
  }
  return(x<-xts(x,order.by=index(y)))
  
  
}
#calls rDens & runAcct
RunAcctSim<-function(dat,n,z){
  sample<-rDens(n=n,z=z,dat=coredata(dat))
  sample<-xts(sample,order.by=seq(as.POSIXct(start(dat)),length.out=length(sample),by=diff(index(dat[1:2]))))
  
  sampleAcct<-runAcct(y=sample)
  return(sampleAcct)
}
#calls RunAcctSim 
AcctMC<-function(month,numrep,len,data,func=RunAcctSim){
  day<-apply.daily(data[.indexmon(data) %in% (month-1)],sum)
  sim.accts<-as.data.frame(replicate(numrep,func(dat=day,n=len,z=day)))
  sim.accts<-xts(sim.accts,order.by=seq(as.POSIXct(start(day)),length.out=len,by='day'))
  
  return(sim.accts)
}
AcctMC.list<-function(month,numrep,len,data,func=RunAcctSim){
  list.out<-list()
  
  
  for(i in 1:(length(data))){
    
    day<-apply.daily(data[[i]][.indexmon(data[[i]]) %in% (month-1)],sum)
    list.out[[i]]<-as.data.frame(replicate(numrep,func(dat=day,n=len,z=day)))
    list.out[[i]]<-xts(list.out[[i]],order.by=seq(as.POSIXct(start(day)),length.out=len,by='day'))
    
  }
  names(list.out)<-sim.names
  return(list.out)
  
}
RiskMetric.list<-function(revenues){
  x<-data.frame(rep(0,ncol(revenues[[1]])))
  for(i in 1:(length(revenues))){
    x<-cbind(x,as.numeric(revenues[[i]][end(revenues[[i]]),]))
  }
  x<-x[,-1]
  names(x)<-names(revenues)
  
  risk.x<-apply(x,2,function(x) (mean(x)-quantile(x,p=.05))/mean(x))
  mu.x<-apply(x,2,mean)
  p05.x<-apply(x,2,function(x) quantile(x,p=.05))
  
  
  df<-as.data.frame(cbind(risk.x,mu.x,p05.x))
  colnames(df)<-c("Risk","Mean","p05 Quantile")
  return(df)
}
RevDensPlot<-function(a,b,c,x,y,z,month){
  require(ggplot2);require(reshape2);require(plyr)
  #create plottable object 
  if(missing(a) && missing(x)){
    
    x<-data.frame(              "Hedged North"=as.numeric(y[end(y),]),
                                "15% Reduction Hedge N"=as.numeric(z[end(z),]),
                                "Hedged West"=as.numeric(b[end(b),]),
                                "15% Reduction Hedge W"=as.numeric(c[end(c),]))
    
  }else{
    x<-data.frame("Merchant North"=as.numeric(x[end(x),]),
                  "Hedged North"=as.numeric(y[end(y),]),
                  "15% Reduction Hedge N"=as.numeric(z[end(z),]),
                  "Merchant West"=as.numeric(a[end(a),]),
                  "Hedged West"=as.numeric(b[end(b),]),
                  "15% Reduction Hedge W"=as.numeric(c[end(c),]))
  }
  dataM<-melt(x)
  mu <-  ddply(dataM, "variable", summarise, mean=mean(value))
  p05<-  ddply(dataM, "variable", summarise, p05=quantile(value,p=.05))
  #generate plots
  plots<-ggplot(dataM, aes(x=value, fill=variable, color=variable)) +
    geom_density(alpha=.25, size=1.5)+
    geom_vline(data=mu, aes(xintercept=mean, color=variable), linetype="dashed")+
    geom_vline(data=p05, aes(xintercept=p05, color=variable), linetype="dashed")+
    geom_text(data=p05,aes(x=p05, label=paste("p.05 = ", p05), y=1e-06,color=variable), angle=90, vjust = -1)+
    geom_text(data=mu,aes(x=mean, label=paste("Mean = ", mean), y=2.0e-06,color=variable), angle=90, vjust = -1)+
    labs(x= "$ Revenues",y="Density",title=paste("Kernel Density 1 Month Revenues,", month))+
    xlim( min( quantile(x[,1],p=.005), quantile(x[,2],p=.005), quantile(x[,3],p=.005)) , 
          max( quantile(x[,1],p=.995), quantile(x[,2],p=.995), quantile(x[,3],p=.995))
    )
  return(plots)
}
RevDensPlot.list<-function(revenues,month){
  require(ggplot2);require(reshape2);require(plyr)
  x<-data.frame(rep(0,ncol(revenues[[1]])))
  for(i in 1:(length(revenues))){
    x<-cbind(x,as.numeric(revenues[[i]][end(revenues[[i]]),]))
  }
  x<-x[,-1]
  names(x)<-names(revenues)
  dataM<-melt(x)
  mu <-  ddply(dataM, "variable", summarise, mean=mean(value))
  p05<-  ddply(dataM, "variable", summarise, p05=quantile(value,p=.05))
  #generate plots
  plots<-ggplot(dataM, aes(x=value, fill=variable, color=variable)) +
    geom_density(alpha=.25, size=1.5)+
    geom_vline(data=mu, aes(xintercept=mean, color=variable), linetype="dashed")+
    geom_vline(data=p05, aes(xintercept=p05, color=variable), linetype="dashed")+
    geom_text(data=p05,aes(x=p05, label=paste("p.05 = ", p05), y=1e-06,color=variable), angle=90, vjust = -1)+
    geom_text(data=mu,aes(x=mean, label=paste("Mean = ", mean), y=2.0e-06,color=variable), angle=90, vjust = -1)+
    labs(x= "$ Revenues",y="Density",title=paste("Kernel Density 1 Month Revenues,", month))+
    xlim( min( quantile(x[,1],p=.005), quantile(x[,2],p=.005), quantile(x[,3],p=.005)) , 
          max( quantile(x[,1],p=.995), quantile(x[,2],p=.995), quantile(x[,3],p=.995))
    )
  return(plots)
}
RiskMetric<-function(a,b,c,x,y,z){
  
  if(missing(a) && missing(x)){
    b<-as.numeric(b[31,])
    c<-as.numeric(c[31,])
    y<-as.numeric(y[31,])
    z<-as.numeric(z[31,])
    
    risk.b<-c("Hedged West  Risk"=as.numeric(mean(b)-quantile(b,p=.05))/mean(b))
    risk.c<-c("15% Reduction Hedge W Risk"  = as.numeric(mean(c)-quantile(c,p=.05))/mean(c))
    risk.y<-c("Hedged North Risk"=as.numeric(mean(y)-quantile(y,p=.05))/mean(y)) 
    risk.z<-c("Hedged North Risk"=as.numeric(mean(z)-quantile(z,p=.05))/mean(z))
    mu.b<-c("Hedged West Mean"= mean(b))
    mu.c<-c( "15% Reduction Hedge W Mean"=mean(c))
    mu.y<-c("Hedged West Mean"=mean(y))
    mu.z<-c("15% Reduction Hedge W Mean"=mean(z))
    p05.b<-c( "Hedged West p05"= quantile(b,p=.05))
    p05.c<-c("15% Reduction Hedge W p05"=quantile(c,p=.05))
    p05.y<-c("Hedged West p05"=quantile(y,p=.05))
    p05.z<-c( "15% Reduction Hedge W p05"=quantile(z,p=.05))
    return( c(rbind(mu.y,p05.y,risk.y),
              rbind(mu.z,p05.z,risk.z),
              rbind(mu.b,p05.b,risk.b),
              rbind(mu.c,p05.c,risk.c)))
  }else{ 
    b<-as.numeric(b[31,])
    c<-as.numeric(c[31,])
    y<-as.numeric(y[31,])
    z<-as.numeric(z[31,])
    a<-as.numeric(a[31,])
    x<-as.numeric(x[31,])
    
    risk.b<-c(as.numeric(mean(b)-quantile(b,p=.05))/mean(b))
    
    risk.c<-c(as.numeric(mean(c)-quantile(c,p=.05))/mean(c))
    
    risk.y<-c(as.numeric(mean(y)-quantile(y,p=.05))/mean(y)) 
    risk.z<-c(as.numeric(mean(z)-quantile(z,p=.05))/mean(z))
    risk.a<-c(as.numeric(mean(a)-quantile(a,p=.05))/mean(a))
    risk.x<-c(as.numeric(mean(x)-quantile(x,p=.05))/mean(x))
    
    mu.a<-c(mean(a))
    mu.b<-c(mean(b))
    mu.c<-c(mean(c))
    mu.x<-c(mean(x))
    mu.y<-c(mean(y))
    mu.z<-c(mean(z))
    p05.a<-c(quantile(a,p=.05))
    p05.b<-c(quantile(b,p=.05))
    p05.c<-c(quantile(c,p=.05))
    p05.x<-c(quantile(x,p=.05))
    p05.y<-c(quantile(y,p=.05))
    p05.z<-c(quantile(z,p=.05))
    
    MU<-rbind(mu.a,mu.b,mu.c,mu.x,mu.y,mu.z)
    P05<-rbind(p05.a,p05.b,p05.c,p05.x,p05.y,p05.z)
    RISK<-rbind(risk.a,risk.b,risk.c,risk.x,risk.y,risk.z)
    df<-as.data.frame(cbind(MU,P05,RISK),row.names=c("Merchant West","Hedged West","ReducedHedgeVol 15%","Merchant North","Hedged North","ReducedHedgeVol 15%"))
    colnames(df)<-c("Mean","p05","Risk")
    return(df)
  }
}

